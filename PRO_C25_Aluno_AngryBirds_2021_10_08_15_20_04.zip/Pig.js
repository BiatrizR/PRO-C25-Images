class Pig 
{
    constructor(x, y) {
      
    }
}
