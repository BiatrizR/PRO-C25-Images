class Log 
{
    constructor(x, y, height, angle) {
     
    }
}
