class Box 
{
  constructor(x, y, width, height) {
    
    
  }
}
